Goal:

UI Design:  We will build a kitchen timer (like Alexa!).  It will display
a list of timers.  Each timer will show a name, the amount of time
left, and a "delete" button.

The user can select a timer by clicking on it.  It will display in
red.  Clicking on a selected timer will unselect it.  Selecting a
timer will unselect all the other timers.

The app will also show a button to mark the passage of time ("Tick!").

We'd like to have a form for adding a new Timer, but that may not be
until a later layer.

We will use elements from the Chakra UI package.

Data Design:

We will use an MVC-style design. We will have a "back-end" model
(TimerModel.ts) that keeps track of all the timer data.  Our front-end will
deal with the data by communicating with the model.

We will have a React component for each timer (TimerComponent.tsx) + a
component for the display (MainComponent.tsx; distinct from
App.tsx). MainComponent will be the only component that talks with the
model.

We'll use Chakra UI elements

================

Build with: 
npx create-react-app the-demo-name --template typescript
cd the-demo-name
npm install --save @chakra-ui/react @emotion/react@^11 @emotion/styled@^11 framer-motion@^6

After you finish the project, you can move it by packing it (using the
script "zip" in package.json), unpacking it in the new location, and
saying "npm install".

================

Development Sequence:

write interface ModelData in Interfaces.ts   (* Data First *)
show Model.ts  (premade)

App.tsx : wrap existing app in <ChakraProvider>

write simple TimerComponent.tsx  (no delete button)
update App.tsx to create a single timer and display it.

write simple MainComponent.tsx, update App.tsx to create 3 timers and
start Main.

update Main to deal with an arbitrary list of timers.

Add style to TimerComponent.tsx

https://www.w3schools.com/css/css_boxmodel.asp

const style = {
        display: "table-cell",
        textVerticalAlign: "middle",
        fontSize: "18px",
        fontFamily: "consolas",
        color: "black" ,     
        width: "200px",
        border: "1px solid", 
        margin: "5px"  ,
        padding: "5px"     
    }

================

Add select/unselect:

MainComponent sends a handler (mainHandleSelect) to each
TimerComponent as the "reportSelect" prop.

The TimerComponent can send a "select" message to the MainComponent by
calling props.reportSelect(props.key)

The TimerComponent sends a handler (timerHandleSelect) to the Box as
the onClick prop.  So when the user clicks in the box, it runs
timerHandleSelect().

Test by changing style to   color: (isSelected)?"red":"black"
(demonstrates programmatic control of styling)

================

Add Tick! button.

Same pattern as select/unselect, except that mainHandleSelect calls
model.tick() .  Observe that this doesn't seem to work.  Add
console.log statement, observe in console that the ticks are
decremented in the model but there's no redisplay.  Add state variable
to force redisplay

================

Delete button

...Similar pattern...

================================================================








