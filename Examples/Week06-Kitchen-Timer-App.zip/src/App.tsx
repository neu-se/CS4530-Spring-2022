import React from 'react';
import logo from './logo.svg';
import './App.css';
import { ChakraProvider } from '@chakra-ui/react'
import { TimerModel } from './TimerModel'
import { TimerComponent } from './TimerComponent';
import { MainComponent } from './MainComponent';

function App() {

  const model1 = new TimerModel
  model1.addTimer("My first timer", 100)
  model1.addTimer("Timer 2", 20)
  model1.addTimer("Timer 3", 30)
  model1.addTimer("Timer 4", 40)


  return (
    <ChakraProvider>
      <MainComponent  model={model1}/>
    </ChakraProvider>
  );
}

export default App;
