import { TimerModel } from './TimerModel'

describe("simple tests", () => {
    var model : TimerModel
    var key3 : number
    beforeEach(() => {
        model = new TimerModel
        model.addTimer("first timer", 25)
        model.addTimer("Timer 2", 30)
        key3 = model.addTimer("Timer 3", 180)
    })
    test("expect keys to be [1,2,3]", () => {
        expect(model.getTimers().map(t => t.key)).toEqual([1,2,3])
    })
    test("initial model should have 3 elements", () => {
        expect(model.getTimers().length).toEqual(3)
    })
    test("deleting a timer should leave 2 elements", () => {
        model.deleteTimerByKey(1);
        expect(model.getTimers().length).toEqual(2)
    })
    test("ticking the model should decrement all the timers", () => { 
        const prev = model.getTimers().map(t => t.timeLeft)
        const next = prev.map(n => n - 1)
        model.tick()
        expect(model.getTimers().map(t => t.timeLeft)).toEqual(next)
    })
})