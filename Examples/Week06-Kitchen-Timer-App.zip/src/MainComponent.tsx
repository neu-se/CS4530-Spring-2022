import React, { useState, useEffect, useCallback } from 'react'
import { TimerData } from "./Interfaces";
import { TimerComponent } from "./TimerComponent";
import { Stack, Heading, Button, useToast } from '@chakra-ui/react'
import { TimerModel } from './TimerModel';





export function MainComponent (props:{model:TimerModel})  {
    const timers = props.model.getTimers()

// the key of the selected timer.   -1 matches nothing
    const [selectedKey,setSelectedKey] = useState<number>(-1)
    
    function mainHandleSelect(reportedKey:number) {
        if (reportedKey === selectedKey) {
            setSelectedKey(-1)
        } else {
            setSelectedKey(reportedKey)
        }
    }

    // Prof. Bell points out that this might be better done with useCallback.
    // useCallback evaluates its first argument only when one of
    // the state variables in the second argument changes, 
    // kind of like useEffect

    const alternateMainHandleSelect = 
        useCallback((reportedKey:number) => {
            if (reportedKey === selectedKey) {
                setSelectedKey(-1)
            } else {
                setSelectedKey(reportedKey)
            }},
            [selectedKey,setSelectedKey]
        )

    function displayTimer(t: TimerData) {
        return (<div>            
            <TimerComponent
                data={t}
                reportSelect={mainHandleSelect}
                reportDelete={mainHandleDelete}
                isSelected={(t.key === selectedKey)}

            />
        </div>
        )
    }

    const [ticks,setTicks] = useState<number>(0)
    function handleTick() {
        props.model.tick()
        // console.log(props.model.getTimers().map(t => t.timeLeft))
        // need to call setTicks to force redisplay
        setTicks(ticks+1)
    }

    
    const [lastDeleted,setLastDeleted] = useState(0)
    function mainHandleDelete(keyToDelete:number) {
        props.model.deleteTimerByKey(keyToDelete)
        setLastDeleted(keyToDelete)
    }
    
    const toast1 = useToast()
    useEffect(() => {
        if (lastDeleted > 0) {
            toast1({
                title: `You deleted timer ${lastDeleted}`,
                isClosable: true
            })
        }
    }, [lastDeleted, toast1])


    // added align="center", which fixed the width problem
    return (
        <Stack width="500" align="center">
            <Heading>My Kitchen Timer App 2022-02-23</Heading>
            <Button width="300" onClick={handleTick}>Tick!</Button>
            {timers.map(t => displayTimer(t))}            
        </Stack>
    )


    
}