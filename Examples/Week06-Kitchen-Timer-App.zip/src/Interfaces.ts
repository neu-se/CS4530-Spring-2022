export interface TimerData {
    name: string
    timeLeft: number
    key: number   // a unique index
}

export interface TimerProps {
    data : TimerData
    // key: number
    isSelected: boolean
    reportSelect(key:number) : void  // report a select action to Main
    reportDelete(key:number) : void  // report a delete action to Main
}