import React from 'react'
import { TimerProps } from './Interfaces'
import { Box, Stack, Text, Button } from '@chakra-ui/react'



export function TimerComponent(props: TimerProps): JSX.Element {
    const style1 = {
        display: "table-cell",
        textVerticalAlign: "middle",
        fontSize: "18px",
        fontFamily: "consolas",
        color: (props.isSelected)? "red":"black" ,     
        width: "300px",
        border: "1px solid", 
        margin: "5px",
        padding: "5px"     
    }  

    const myKey = props.data.key

    function timerHandleSelect() {
        props.reportSelect(myKey)
    }

    function timerHandleDelete() {
        props.reportDelete(myKey)
    }

    return (
        <Box style={style1} onClick={timerHandleSelect}>
            <Stack>
                <Text>
                    {props.data.name}: {props.data.timeLeft}
                </Text>
                <Button onClick={timerHandleDelete}>Delete</Button>
            </Stack>
        </Box>
    )
}