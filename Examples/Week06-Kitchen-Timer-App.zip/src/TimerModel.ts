// model of the timer.
// all the data is kept here

import { TimerData } from './Interfaces'

export class TimerModel {
    public timers : TimerData[] = []

    private nTimers : number = 0

    public addTimer(name:string, timeLeft:number) : number {
        this.nTimers++
        this.timers.push({name: name, timeLeft: timeLeft, key: this.nTimers}) 
        return this.nTimers
    }

    public deleteTimerByKey(keyForDeletion:number) {
        this.timers = this.timers.filter((timer) => (timer.key !== keyForDeletion))
    }

    public getTimers() : TimerData[] {return this.timers}

    public tick() {
        // only change one component, so this idiom is clearer.
        this.timers.forEach((_, index) => { this.timers[index].timeLeft-- })
    }    

}