interface AbsConsumer {
    notify(t:number):void
}

export interface AbsObservedClock {
    reset():void  // resets the time to 0
    tick():void   // increments the time
    addObserver(obs:AbsConsumer):void // 
}

export class ObservedClock implements AbsObservedClock {
    time: number = 0
    reset() { this.time = 0 } 
    tick() { this.time++; this.notifyAll() }     
    
    private observers: AbsConsumer[] = []
    public addObserver(obs:AbsConsumer){this.observers.push(obs)}
    private notifyAll() {
            this.observers.forEach(obs => obs.notify(this.time))
        }
}

export class ObservedClockClient implements AbsConsumer {
    constructor (private theclock:AbsObservedClock) {
        theclock.addObserver(this)
    }
    private time = 0  // is this the best way to initialize the time?
    notify (t:number) {this.time = t}
    getTime () {return this.time}
}

// the Observer gets to decide what to do with the notification
export class DifferentClockClient implements AbsConsumer {
    constructor (private theclock:AbsObservedClock) {
        theclock.addObserver(this)
    }
    private time = 0
    private notifications : number[] = [] // just for fun
    notify(t: number) { 
        this.notifications.push(t)
        this.time =  t * 2 }
    getTime() { return (this.time / 2) }
}





