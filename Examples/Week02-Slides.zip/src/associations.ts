class Teacher {
    coursesTaught : Course[]
}

class Course {
    instructor : Teacher
    roster : Student[]
}

class Student {
    classesTaking : Course[]
}

// INVARIANT
// c.instructor = t iff c is in t.coursesTaught
// s in c.roster iff c is in s.classes