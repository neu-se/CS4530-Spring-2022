import AbsClock from './AbsClock'
// use whichever clock factory is exported from clockFactories
import ClockFactory from './clockFactories'


export class SingletonClockFactory0  {
    private constructor() {}

    private static theClock : AbsClock  // initially undefined!

    public static instance () : AbsClock {
        if (SingletonClockFactory0.theClock === undefined) {
            SingletonClockFactory0.theClock 
                = (new ClockFactory).instance()
        };
        return SingletonClockFactory0.theClock
    }
}

// the code above depends on the peculiarity that in TS, 
// theClock will be initially undefined.
// here's a solution that doesn't depend on that language property
export class SingletonClockFactory  {
    private constructor() {}

    private static isInitialized : boolean = false

    private static theClock : AbsClock  

    public static instance () : AbsClock {
        if (!(SingletonClockFactory.isInitialized)) {            
            SingletonClockFactory.theClock
                = (new ClockFactory).instance()
            SingletonClockFactory.isInitialized = true
        };
        return SingletonClockFactory.theClock
    }
}

export default SingletonClockFactory
