// import {Square, Circle, ShapeArray, area} from './area1'
import {Square, Circle, ShapeArray, area} from './area2'

describe( "tests of area1", () => {
    test("test of square", () => {
        expect(area(new Square(2))).toBe(4)
    })

    test("test of circle", () => {
        expect(area(new Circle(2))).toEqual(Math.PI*4)
    })

    test("test of ShapeArray", () => {
        expect(area(new ShapeArray(new Square(2), 3))).toEqual(12)
    })

    test("test of nested arrays", () => {
        const array1 = new ShapeArray(new Square(2), 3)
        const array2 = new ShapeArray(array1, 10)
        expect(area(array2)).toEqual(120)
    })


})