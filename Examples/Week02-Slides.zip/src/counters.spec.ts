// getCounter ()   always returns an even number
// bumpCounter (n) increases the value of the counter
interface Interface1 {
    getCounter(): number
    bumpCounter(n: number): void
}

class Class1 implements Interface1 {
    private counter = 0
    // INVARIANT: counter is even
    public getCounter() { return this.counter }
    public bumpCounter(n: number): void {
        // the interface didn't say anything about what do with n.
        this.counter = this.counter + 2
    }
}

class Class2 implements Interface1 {
    public counter = 0
    // INVARIANT: counter is even
    public getCounter() { return this.counter }
    public bumpCounter(n: number): void {
        // the interface didn't say anything about what do with n.
        this.counter = this.counter + 2
    }
}

test("test Class2", () => {
    const o = new Class2();
    o.counter++;
    expect(o.getCounter()).toBe(1)
})




