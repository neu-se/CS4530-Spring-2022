import { DifferentClockClient, ObservedClock, ObservedClockClient } from "./clockUsingPush";

describe("tests of observed clock", () => {           
    
    test("single observer", () => {
        const clock1 = new ObservedClock()
        const observer1 = new ObservedClockClient(clock1)
        expect(observer1.getTime()).toBe(0)
        clock1.tick()
        clock1.tick()
        expect(observer1.getTime()).toBe(2)
    })

    test("test of DifferentClockClient", () => {
        const clock1 = new ObservedClock()
        const observer1 = new DifferentClockClient(clock1)
        expect(observer1.getTime()).toBe(0)
        clock1.tick()
        expect(observer1.getTime()).toBe(1)
        clock1.tick()
        expect(observer1.getTime()).toBe(2)
    })

    test("Multiple Observers", () => {
        const clock1 = new ObservedClock()
        const observer1 = new DifferentClockClient(clock1)
        const observer2 = new ObservedClockClient(clock1)
        const observer3 = new ObservedClockClient(clock1)
        clock1.tick()
        clock1.tick()
        expect(observer1.getTime()).toBe(2)
        expect(observer2.getTime()).toBe(2)
        expect(observer3.getTime()).toBe(2)
    })

})

