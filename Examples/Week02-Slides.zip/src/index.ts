import { SimpleClock, ClockClient } from "./simpleClockUsingPull";

// create a clock and test it
const clock1 = new SimpleClock
console.log(clock1.getTime())  // should print (0)
clock1.tick()
clock1.tick()
console.log(clock1.getTime())  // should print (2)
clock1.reset()
console.log(clock1.getTime())  // should print (0)
// now test the client
const client1 = new ClockClient(clock1)
console.log(clock1.getTime())  // should print (0)
console.log(client1.getTimeFromClock())  // should print (0)
clock1.tick()
clock1.tick()
console.log(client1.getTimeFromClock())  // should print (2)

