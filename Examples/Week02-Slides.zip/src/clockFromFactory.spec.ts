import { ClockClient } from "./simpleClockUsingPull";
import ClockFactory from './clockFactories'


test("test of the Clock produced by the ClockFactory", () => {
    const factory1 = new ClockFactory
    const clock1 = factory1.instance()
    expect(clock1.getTime()).toBe(0)
    clock1.tick()
    clock1.tick()   
    expect(clock1.getTime()).toBe(2)
    clock1.reset()
    expect(clock1.getTime()).toBe(0)
})
test("test of ClockClient", () => {
    const factory1 = new ClockFactory
    const clock1 = factory1.instance()
    expect(clock1.getTime()).toBe(0)
    const client1 = new ClockClient(clock1)
    expect(clock1.getTime()).toBe(0)
    expect(client1.getTimeFromClock()).toBe(0)
    clock1.tick()
    clock1.tick()
    expect(client1.getTimeFromClock()).toBe(2)
})
