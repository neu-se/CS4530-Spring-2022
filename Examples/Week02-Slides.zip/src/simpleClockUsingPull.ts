import AbsClock from "./AbsClock";

export class SimpleClock implements AbsClock {
    private time = 0
    public reset () {this.time = 0}
    public tick () { this.time++ }
    public getTime(): number { return this.time }
}

export class ClockClient {
    constructor (private theclock:AbsClock) {}
    getTimeFromClock ():number {return this.theclock.getTime()}
}

