import AbsClock from './AbsClock'
// the raw materials
import * as Clocks from './clocks'


interface AbsClockFactory {
    clockType : string
    instance() : AbsClock 
    numCreated() : number
}



abstract class ClockFactorySuperClass implements AbsClockFactory {
    abstract clockType: string
    protected abstract buildClock() : AbsClock
    protected numcreated = 0    
    public instance() : AbsClock {
        this.numcreated++;
        return this.buildClock()
    }
    public numCreated() {return this.numcreated}
}

class ClockFactory1asSubclass extends ClockFactorySuperClass
 implements AbsClockFactory {
    clockType = "Clock1" 
    protected buildClock() : AbsClock {
        return new Clocks.Clock1}
}
class ClockFactory2asSubclass extends ClockFactorySuperClass
 implements AbsClockFactory {
    clockType = "Clock2" 
    protected buildClock() : AbsClock {
        return new Clocks.Clock2}    
}