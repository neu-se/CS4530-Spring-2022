# Sample REST app using express.js

Learning Objectives for this activity:
* Practice applying asynchronous programming concepts: promises, async/await
* Experiment with applying different ordering constraints in asynchronous code

## Overview
In this activity, you will experiment with asynchronous programming constructs in TypeScript.

### Getting started
Run `npm install` to download the dependencies for this project, and then open it in your IDE of choice. 
Run `npm run client` to run the client as-is, the output should be something like:

```
starting script1()
script1 says: getTranscript(2) says: {
  student: { studentID: 2, studentName: 'blake' },
  grades: [ { course: 'DemoClass', grade: 80 } ]
}
script1 says: students named blake: [ 2, 3 ]
script1 says { studentID: 2, course: 'cs101', grade: 85 }
script1 succeeded
```

### Stringing together many async calls: bulk importing grades
Examine the transcript server client in `client.ts`, and . Write a new, `async` function, `importGrades`, which takes in input of the format:
```
[
    {
        studentName: "Avery",
        grades: [{course: "Software Engineering", grade: 100}, {course: "Chemistry", grade: 70}],
    },
    {
        studentName: "Ripley",
        grades: [{course: "Underwater Basket Weaving", grade: 100}, {course: "Kayaking", grade: 90} ]
    }
]
```
`importGrades` should create a student record for each student passed, and file the grades for each of those students. After posting the grades, it should fetch the transcripts for each student and return an array of transcripts. 

If you finish quickly, you might also try to implement this three ways:
1. Insert a student, insert each of their grades (in order), then insert the next student, then their grades, etc. until all students are inserted, then fetch transcripts
2. Insert a student, then insert each of their grades (in order), then fetch their transcript. Do this set of operations asynchronously (concurrently) for all students
3. Insert a student, then insert each of their grades asynchronously (concurrently). After all students have all of their grades submitted, fetch all fo the transcripts asynchronously (concurrently)
