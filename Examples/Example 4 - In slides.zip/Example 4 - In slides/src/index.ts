import axios from 'axios';

// function makeOneGetRequestNoAsync(): Promise<void> {
//   console.log('Making Request');
//   return axios.get('https://rest-example.covey.town').then(
//     (response) =>{
//       console.log('Heard back from server');
//       console.log(response.data);
//     },
//   );
// }

// async function makeOneGetRequest(): Promise<void> {
//   console.log('Making Request');
//   const response = await axios.get('https://rest-example.covey.town');
//   console.log('Heard back from server');
//   console.log(response.data);
// }
async function makeOneGetRequest(){
  const response = await axios.get('https://rest-example.covey.town');
  console.log('Heard back from server');
  console.log(response.data);
}
async function makeThreeSerialRequests(){
  console.log('Making first request');
  await makeOneGetRequest();
  console.log('Making second request');
  await makeOneGetRequest();
  console.log('Making third request');
  await makeOneGetRequest();
  console.log('All done!');
}
makeThreeSerialRequests();
console.log('Making first request');
makeOneGetRequest().then( () =>{
  console.log('Making second request');
  return makeOneGetRequest();
}).then( () => {
  console.log('Making third request');
  return makeOneGetRequest();
}).then(()=>{
  console.log('All done!');
});
//
// let initalData :string|undefined = undefined;
// async function loadInitialData(){
//   const response = await axios.get('https://rest-example.covey.town');
//   initalData = response.data;
// }
// let x = 0;
// async function increment(){
//   x = x + 1;
//   const response = await axios.get('https://rest-example.covey.town');
//   console.log(`Heard back: ${response.data}`);
// }
// async function processRequest(){
//   if(initalData == null)
//   {
//     await loadInitialData();
//   }
//   console.log(`Processing request, using initialized data: ${initalData}`);
// }

// makeOneGetRequest();
// console.log('All done!');
// async function makeThreeSerialRequests(): Promise<void> {
//   const start = Date.now();
//   await makeOneGetRequest();
//   await makeOneGetRequest();
//   await makeOneGetRequest();
//   const duration = Date.now() - start;
//   console.log(`Total time for 3 requests: ${duration}`)
// }
//
// makeThreeSerialRequests();
// console.log('All done!');

// function makeOneGetRequestNoAsync(): Promise<void> {
//   console.log("Making Request");
//   return axios.get("https://rest-example.covey.town").then((response) => {
//     console.log("Heard back from server");
//     console.log(response.data);
//   }).catch(err => {
//     console.log('Uh oh!');
//     console.trace(err);
//   });
// }

// async function makeOneGetRequest(): Promise<void> {
//   console.log("Making Request");
//   try {
//     const response = await axios.get("https://rest-example.covey.town");
//     console.log("Heard back from server");
//     console.log(response.data);
//   } catch(err){
//     console.log('Uh oh!');
//     console.trace(err);
//   }
// }
// async function makeThreeGetRequests() {
//   const start = Date.now();
//   await Promise.all([
//     makeOneGetRequest(),
//     makeOneGetRequest(),
//     makeOneGetRequest(),
//   ]);
//   const duration = Date.now() - start;
//   console.log(`Heard back from all of the requests in ${duration} ms`);
// }
// makeThreeGetRequests();

/*
async function makeOneGetRequest(requestNumber: number){
    console.log(`Making request ${requestNumber}`)
    const response = await axios.get('http://rest-example.covey.town');
    console.log(`Heard back from server for request ${requestNumber}:`);
    console.log(response.data);
}
makeOneGetRequest(1);
makeOneGetRequest(2);
console.log('All done!');
*/
// axios.get('http://rest-example.covey.town/').then(response => {
//   console.log('Heard back from server');
//   console.log(response.data);
// }).catch(err => {
//   console.log("Uh oh!");
//   console.trace(err);
// });
