export default class Venusian {
} 